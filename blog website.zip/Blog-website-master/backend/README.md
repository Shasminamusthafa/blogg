```.env``` file contains <br/>
```MONGO_URI <br/>
GOOGLE_CLIENT
GOOGLE_SECRET
COOKIE_KEY
TOKEN_SECRET
CLOUD_NAME (of cloudinary)
CLOUD_API_KEY
CLOUD_API_SECRET
PASS (google app password for nodemailer)
REACT_APP_BACKEND_URL=http://localhost:5000```
